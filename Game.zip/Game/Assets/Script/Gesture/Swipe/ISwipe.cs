using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISwipe 
{
    void OnSwipe(SwipeEventArgs args);
}
