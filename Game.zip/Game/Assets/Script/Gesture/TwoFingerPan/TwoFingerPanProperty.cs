using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class TwoFingerPanProperty 
{
    public float MaxDistance = 0.4f;
}
