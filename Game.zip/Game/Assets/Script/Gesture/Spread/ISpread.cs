using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISpread 
{
    void OnSpread(SpreadEventArgs args);
}
