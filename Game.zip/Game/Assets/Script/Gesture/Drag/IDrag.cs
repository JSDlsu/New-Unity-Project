using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IDrag 
{
    void OnDrag(DragEventArgs args);
}
