using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ITwoFIngerPan
{
    void OnTwoFingerPan(TwoFingerPanEventArgs args);
}
